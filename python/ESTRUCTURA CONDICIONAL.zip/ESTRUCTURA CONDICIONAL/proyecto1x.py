"""EVALUAR LA EDAD INGRESADA
0>= Y <2, Eres un baby
2>= Y <12, Eres un niñ@
12>= Y <17, Eres un Adolescente
18>= Y <40, Eres un adulto joven
40>= Y <60, Eres un adulto maduro
>=60, Eres un adulto mayor
"""

edad=int(input("ingrese la edad: "))

if edad>=0 and edad<2:
    print("Eres un baby")
elif edad>=2 and edad<12:
    print("Eres un niño")
elif edad>=12 and edad<=17:
    print("Eres un adolescente")
elif edad>=18 and edad<40:
    print("Eres un adulto joven")
elif edad>=40 and edad<60:
    print("Eres un adulto maduro")
elif edad>=60:
    print("Eres un adulto mayor")
else:
    print("!!Esto no es una edad, por favor verifique!!")