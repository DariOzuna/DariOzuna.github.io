"""
APP PARA UN ALMACEN DE ZAPATOS
tiene una promocion de descuento para vender al mayor,dependera del numero
de zapatos que se compren.EL precio debe ser ingresado
<10, no hay descuento,
10>= y <20, 10% de descuento
20>= y <30, 20%  de descuento
30>=, 40%, de descuento
"""
precio=int(input("Ingrese el precio del par de zapatos"))
cantidad=int(input("Digite la cantidad de zapatos comprados"))

if cantidad<10:
    subtotal=precio*cantidad
    print("El valor de su compra es de:" ,subtotal)
    print("Usted no recibio ningun descuento")
elif cantidad>=10 and cantidad<20:
    subtotal=precio*cantidad
    descuento=subtotal*0.10
    pagar=subtotal-descuento
    print("Usted ha recibido un descuento del 10% que equivale a :" ,descuento, "pesos")
    print("El dinero total a cancelar es de  :" ,pagar, "pesos")
elif cantidad>=20 and cantidad<30:
    subtotal=precio*cantidad
    descuento=subtotal*0.20
    pagar=subtotal-descuento
    print("Usted ha recibido un descuento del 20% que equivale a :" ,descuento, "pesos")
    print("El dinero total a cancelar es de  :" ,pagar, "pesos")
elif cantidad>=30:
    subtotal=precio*cantidad
    descuento=subtotal*0.40
    pagar=subtotal-descuento
    print("Usted ha recibido un descuento del 40% que equivale a :" ,descuento, "pesos")
    print("El dinero total a cancelar es de  :" ,pagar, "pesos")

