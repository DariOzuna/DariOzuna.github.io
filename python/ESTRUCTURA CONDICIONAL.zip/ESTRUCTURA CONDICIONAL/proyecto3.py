#Diseñe un algoritmo que ingrese la edad y diga si es MAYOR DE EDAD o MENOR DE EDAD.
edad=int(input("Digite la edad de la persona: "))

if edad>=18:
    print("la persona tiene ",edad, "años por lo que se considera mayor de edad")
else:
    print("la persona tiene ",edad, "años por lo que se considera menor de edad")