"""
App de masa corporal
"""
peso=int(input("Ingrese el peso (Kg): "))
estatura=float(input("Ingrese la estatura (m): "))
imc=peso/(estatura*estatura)
print("Su Imc es ",imc," Kg/m^2")
if imc<18.5: 
    print("Se encuentra en Bajo peso")
elif imc>=18.5 and imc<=24.9:
    print("El paciente se encuentra en Normal")
elif imc>=25 and imc<=29.9:
    print("El paciente se encuentra en Sobrepeso")
elif imc>=30 and imc<=34.9:
    print("El paciente se encuentra en Obesisad I")
elif imc>=35 and imc<=39.9:
    print("El paciente se encuentra en Obesidad II")
elif imc>=40 and imc<=49.9:
    print("El paciente se encuentra en Obesidad III")
elif imc>50:
    print("El paciente se encuentra en Obsesidad lV")
else:
    print("Verifique el valor de peso y estatura ingresado")

   
