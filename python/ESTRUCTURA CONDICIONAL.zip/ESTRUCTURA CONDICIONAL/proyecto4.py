#Diseñe un algoritmo que ingrese una nota; Si la nota es mayor igual a 3 entonces es APROBADO, si no, REPROBADO.

nota=float(input("Digite la nota que obtuvo el estudiante: "))

if nota>3.0:
    print("El estudiante aprobo")
else:
    print("El estudiante reprobo")