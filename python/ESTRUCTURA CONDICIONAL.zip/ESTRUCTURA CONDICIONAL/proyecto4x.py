"""
APP DE PRESION ARTERIAL
BAJA 
NORMAL 
HIPERTENSION
ALTA-FASE 1
ALTA-FASE 2
"""

presion=int(input("Ingrese la presion que tiene la persona"))

if presion<90:
    print("la presion arterial se encuentra baja")
elif presion<=120:
    print("la presion arterial se encuentra normal")
elif presion>=120 and presion<=139:
    print("usted tiene prehipertencion")
elif presion>=140 and presion<=159 :
    print("usted tiene hipertension fase I")
elif presion>=160:
    print("usted tiene hipertension fase II")
else:
    print("!! por favor verifique!!")
   