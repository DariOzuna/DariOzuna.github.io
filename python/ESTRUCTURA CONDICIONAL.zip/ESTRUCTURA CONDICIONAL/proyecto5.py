#Diseñe un algoritmo que ingrese una temperatura en ºC y diga si el paciente tiene FIEBRE con una temperatura mayor igual a 38 o tiene una TEMPERATURA NORMAL.

temperatura=int(input("Digite la temperatura que tiene el paciente: "))

if temperatura>=38:
    print("El paciente tiene fiebre")
else:
    print("El paciente no tiene fiebre")