# Diseñe Un algoritmo que ingrese un valor de ingreso 
# y un valor de ganancias; Si el ingreso es mayor al gasto es GANANCIA sino es PERDIDA.

ingresos=int(input("Digite el valor de sus ingresos: "))
gastos=int(input("Ingrese el valor de sus gastos: "))

if ingresos>gastos:
    print("Usted ha generado ganancias")
else:
    print("Usted ha generado perdidas")