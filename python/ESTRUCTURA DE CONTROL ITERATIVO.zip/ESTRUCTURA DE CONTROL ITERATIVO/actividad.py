#escribir y diseñar una app que pida al usuario una palabra y la muestre 10 veces por pantalla
#diseñar una app que pregunte al usuario la edad y muestre por pantalla todos los años que ha cumplido(1 hasta su edad)
#diseñar una app que al ingresar un numero entero positivo muestre por pantalla  desde 1 hasta el numero ingresado separado por comas




