#while: APP que me muestre los numeros pares del 1 al 10

i=2

while i<=100:
    print(i)
    i+=2
