#while: APP que me muestre los numeros impares del 1 al 100

i=3

while i<=100:
    print(i)
    i+=3
