#while: APP que me muestre la suma de los numeros del 1 al 100

i=1
s=0
while i<=100:
    s=s+i
    i+=1
    print(s)
   



