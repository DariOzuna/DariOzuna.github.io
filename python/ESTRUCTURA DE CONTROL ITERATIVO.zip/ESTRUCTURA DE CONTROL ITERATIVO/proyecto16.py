#while: APP que me muestre la multiplicacion de los numeros del 1 al 100

i=1
m=1
while i<=100:
    m=m*i
    i+=1
    print(m)
    

