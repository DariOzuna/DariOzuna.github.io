#para(for): APP que me muestre los numeros impares del 1 al 100

for i in range(3,101,3):
    print(i)
