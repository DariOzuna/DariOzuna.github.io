
#escribir y diseñar una app que pida al usuario una palabra y la muestre 10 veces por pantalla
x=str(input("Digite cualquier palabra: "))
i=x
for i in range(1,11):
    print(x)
