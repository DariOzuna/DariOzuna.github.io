#para(for): APP que me muestre los numeros del 1 al 10

for i in range(1,11):
    print(i)
else:
    print("Los valores no son correctos")