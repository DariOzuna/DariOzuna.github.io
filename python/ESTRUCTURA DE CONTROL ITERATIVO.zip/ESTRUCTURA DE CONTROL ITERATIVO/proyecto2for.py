#para(for): APP que me muestre los numeros del 100 al 1

i=0
for i in range(1,101,1):
    print(i)
