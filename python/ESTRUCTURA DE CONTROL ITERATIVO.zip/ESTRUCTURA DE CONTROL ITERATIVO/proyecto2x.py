#diseñar una app que pregunte al usuario la edad y muestre por pantalla todos los años que ha cumplido(1 hasta su edad)

e=int(input("Digite su edad: "))

i=e

for i in range(1, e+1):
    print(i, "años")
    i+=1