#app usuario ingresa el valor 
#inicial y el valor final
x=int(input("Digite el valor inicial: "))
y=int(input("Digite el valor final: "))

i=x
while i<=y:
    print(i)
    i+=1
else:
    print("Los valores no son correctos")