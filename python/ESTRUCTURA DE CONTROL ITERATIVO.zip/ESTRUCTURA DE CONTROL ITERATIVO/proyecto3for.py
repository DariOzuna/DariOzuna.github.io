#para(for): APP que me muestre los numeros pares del 1 al 100

for i in range(2,101,2):
    print(i)
