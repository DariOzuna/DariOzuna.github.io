#diseñar una app que al ingresar un numero entero positivo muestre por pantalla  desde 1 hasta el numero ingresado separado por comas
x=int(input("Ingrese un numero: "))

i=1

while i<=x:
    print(i, end=",")
    i+=1