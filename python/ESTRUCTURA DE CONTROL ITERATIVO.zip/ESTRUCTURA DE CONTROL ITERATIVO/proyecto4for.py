#para(for): APP que me muestre la multiplicacion de los numeros del 1 al 100
m=1
for i in range(1,101,1):
    m=m*i
    print(m)


