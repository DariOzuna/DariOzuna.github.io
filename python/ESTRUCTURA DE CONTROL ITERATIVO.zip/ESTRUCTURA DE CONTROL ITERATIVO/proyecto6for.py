#para(for): APP que me muestre la suma de los numeros del 1 al 100
s=0
for i in range(1,101,1):
    s=s+i
    print(s)


