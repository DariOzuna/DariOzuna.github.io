#Array lista

#DISEÑAR EN PYTHON LAS SIGUIENTES LISTAS Y REALIZAR SU RECORRIDO 
#1. LISTAS DE LIBROS CON 7 POSICIONES.
#2. LISTAS DE PLANTAS MEDICINALES CON 9 POSICIONES. 
#3. LISTAS DE LENGUAJES DE PROGRAMACION CON 5 POSICIONES.
#4. LISTAS DE COLORES CON 8 POSICIONES.

print("**LISTAS DE LIBROS CON 7 POSICIONES**")
libros=["El principito" , "Cien años de soledad" , "Ojos del perro siberiano" ,"La odisea" , "Amalia" , "Biblia" , "Harry potter" ]
#añadimos un elemento a la lista
libros.append("los miserables")
#elimar un elemento de la lista
libros.pop(1)
#Recorremos la lista
for x in libros:  
    print(x)
#definimos la longitud de la lista
longitud=len(libros)
print("El tamaño de longitud es :" , longitud)

print("\n")
print("**Lista de plantas medicinales**")
plantas=["Menta" , "Regaliz" , "Sol de oro" ,"Valeriana" , "Ajo" , "Lavanda" , "Saúco", "Diente de león" ,"Ortiga"]
#añadimos un elemento a la lista
plantas.append("Eucalipto")
#elimar un elemento de la lista
plantas.remove("Menta")
#Recorremos la lista
for x in plantas:
    print(x)
#definimos la longitud de la lista
longitud=len(plantas)
print("El tamaño de longitud es :" , longitud)

print("\n")
print("**lenguajes_programacion**")
lenguajes_programacion=["JAVA" , "Python" , "C++" ,"SQL" , "JavaScript"]
#añadimos un elemento a la lista
lenguajes_programacion.append("PHP")
#elimar un elemento de la lista
lenguajes_programacion.remove("SQL")
#Recorremos la lista
for x in lenguajes_programacion:
    print(x)
#definimos la longitud de la lista
longitud=len(lenguajes_programacion)
print("El tamaño de longitud es :" , longitud)


print("\n")
print("**listas de colores**")
colores=["Amarillo" , "Azul" , "Rojo" ,"Negro" , "gris" , "naranja" , "Rosado" , "verde" , "Morado"]
#añadimos un elemento a la lista
colores.append("Blanco")
#elimar un elemento de la lista
colores.pop(3)
#Recorremos la lista
for x in colores:
    print(x)
#definimos la longitud de la lista
longitud=len(colores)
print("El tamaño de longitud es :" , longitud) 
