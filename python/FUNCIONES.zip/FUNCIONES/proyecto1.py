#Funcion sin parametros
def dihola():
    print("Hello")
#llamando a la funcion
dihola()