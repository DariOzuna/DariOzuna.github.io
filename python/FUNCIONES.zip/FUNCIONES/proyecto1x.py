"""Funcion con parametros 
-funcion suma"""

def suma(a,b):
    sum=a+b
    print("la suma es: " ,sum)

#app que sume dos numeros enteros
a=int(input("Digite el primer numero: "))
b=int(input("Digite el segundo numero: "))
#llamando a la funcion
suma(a,b)