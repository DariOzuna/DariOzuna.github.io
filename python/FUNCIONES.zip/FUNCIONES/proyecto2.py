#Funcion sin parametros ,que permita sumar dos numeros
#Funcion suma
def suma():
    sum=a+b
    print("La suma es:", sum)
#app para sumar dos numeros
a=int(input("Digite el primer numero: "))
b=int(input("Digite el segundo numero: "))

suma()