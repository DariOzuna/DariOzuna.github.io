#calculadora
#funciones con parametros
def suma(a,b):
    sum=a+b
    print("-------------------")
    print("La suma es:", sum)
    print("-------------------")
def resta(a,b):
    res=a-b
    print("la resta es:",res)
    print("-------------------")

def multiplicacion(a,b):
    mul=a*b
    print("la multiplicacion es:",mul)
    print("-------------------")

def division(a,b):
    div=a/b
    print("la division es:",div)
    print("-------------------")

#algoritmo que calcule dos valores ingresados por el usuario
print("-------------------------")
print("       Calculadora       ")
print("-------------------------")
a=int(input("-Digite el primer numero: "))
b=int(input("-Digite el segundo numero: "))
#llamando las funciones
suma(a,b)
resta(a,b)
multiplicacion(a,b)
division(a,b)