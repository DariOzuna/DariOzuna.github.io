"""Funciones con parametros
escribir una funcion a la que se le pase una cadena nombre y muestre por pantalla el saludo completo"""

#funcion de saludo
def saludo(name):
    print("Hola",name)

#app que ingrese un nombre y lo muestre como saludo 
nombre=input("Cual es tu nombre?: ")
#llamando a la funcion
saludo(nombre)