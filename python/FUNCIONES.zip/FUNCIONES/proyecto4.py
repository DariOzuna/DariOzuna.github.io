"""una funcion que me convierta de horas a minutos"""

#funcion
def minutos(): 
    min=horas*60
    print(horas , "horas equivalen a" ,min, "minutos")

#algoritmo para convertir de horas a minutos
print("========================")
print("        Convertir      ")
print("========================")

horas=int(input("Digite la cantidad de horas a convertir: "))

#llamando la funcion
print("------------------------------")
minutos()
print("------------------------------")


