"""2.diseñe una aplicacion con una funcion que calcule el area del triangulo y esa sea llamada por un algoritmo"""

#Funcion sin parametros 
def area(): 
    ar=(base*altura)/2
    print("El area del triangulo es: ",ar)
#algoritmo que calcule area del triangulo
print("----------------------------")
print("     Area del triangulo    ")
print("----------------------------")
base=float(input("Digite la base del triangulo: "))
altura=float(input("Digite la altura del triangulo: "))
#llamda la funcion
area()