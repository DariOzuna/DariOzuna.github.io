"""1.diseña una aplicacion que calcule el area del rectangulo y luego sea llamada por un algoritmo"""


#Funcion sin parametros 
def area(): 
    ar=base*altura
    print("El area del rectangulo es: ",ar)
#algoritmo que calcule area del rectangulo
print("----------------------------")
print("     Area del rectangulo    ")
print("----------------------------")
base=int(input("Digite la base del rectangulo: "))
altura=int(input("digite la altura del rectangulo: "))
#llamda la funcion
area()