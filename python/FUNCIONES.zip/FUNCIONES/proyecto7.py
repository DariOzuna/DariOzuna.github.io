"""3.Diseñe una aplicacion con una funcion que calcule el area del circulo y sea llamada por un algoritmo"""

#Funcion sin parametros 
def area(): 
    ar=3.1415*pow(r,2)
    print("El area del circulo es: ",ar)
#algoritmo que calcule area del circulo
print("----------------------------")
print("      Area del circulo      ")
print("----------------------------")
r=int(input("Digite el valor del radio del circulo: "))

#llamar la funcion
area()