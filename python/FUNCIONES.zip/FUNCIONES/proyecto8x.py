"""4.Diseñe una aplicacion con una funcion que calcule el area del cuadrado y sea llamada por un algoritmo"""
#algoritmo con parametros
def area(l1,l2): 
    ar=l1*l2
    print("El area del cuadrado es: ",ar)
#algoritmo que calcule area del cuadrado
print("----------------------------")
print("     Area del cuadrado      ")
print("----------------------------")
l1=int(input("Digite el primer lado del cuadrado: "))
l2=int(input("Digite el segundo lado del cuadrado: "))
#llamar la funcion
area(l1,l2)